import os
from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime, timedelta
from models import db, User, WC 

app = Flask(__name__)

# Konfiguratsioon
app.config['SECRET_KEY'] = 's3cr3t_k3y_wc_timer'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///wctimer.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Laienduste initsialiseerimine
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Taimeri parameetrid
BOOKING_DURATION = timedelta(minutes=3) 
VIP_DURATION = timedelta(minutes=5)     

@login_manager.user_loader
def load_user(user_id):
    """Laeb kasutaja ID järgi."""
    return db.session.get(User, int(user_id))

def check_and_clear_old_bookings():
    """Kontrollib ja tühistab aegunud broneeringud."""
    now = datetime.now()
    expired_wcs = WC.query.filter(
        WC.status == 'booked',
        WC.booked_until <= now
    ).all()

    for wc in expired_wcs:
        wc.status = 'available'
        wc.booked_until = None
        wc.booked_by_user_id = None
        print(f"WC {wc.name} broneering aegus ja tühistati.")
    
    db.session.commit()

@app.before_request
def check_bookings_on_request():
    """Käivitab tühistamise iga kord, kui keegi teeb lehele päringu."""
    check_and_clear_old_bookings()


# Funktsioon: Leiab vaba Külalise konto
def find_available_guest_id():
    """Leiab esimese külaliskonto, kes ei ole hetkel ühtegi WC-d broneerinud."""
    guest_ids = [u.id for u in User.query.filter_by(is_guest=True).all()]
    booked_ids = [wc.booked_by_user_id for wc in WC.query.filter(WC.booked_by_user_id != None).all()]
    
    for guest_id in guest_ids:
        if guest_id not in booked_ids:
            return guest_id
    
    return None 

# ----------------- MARSRUUDID -----------------

@app.route('/')
def home_redirect():
    """Avalik leht suunab kohe sisselogimise lehele."""
    if not current_user.is_authenticated:
        return redirect(url_for('login'))
    return redirect(url_for('index'))


@app.route('/index') 
@login_required
def index():
    """Pealeht WC-de olekute kuvamiseks."""
    wcs = WC.query.order_by(WC.id).all()
    return render_template('index.html', wcs=wcs, current_time=datetime.now())


@app.route('/book/<int:wc_id>')
@login_required
def book_wc(wc_id):
    """WC broneerimine VIP-prioriteediga."""
    
    wc = db.session.get(WC, wc_id)
    if not wc:
        flash('Vetsu ei leitud.', 'error')
        return redirect(url_for('index'))
    
    is_vip_booking = current_user.is_vip
    duration = VIP_DURATION if is_vip_booking else BOOKING_DURATION
    
    if wc.status == 'booked':
        booked_by = db.session.get(User, wc.booked_by_user_id)
        
        # Juhus A: Kinni, broneeritud teise VIPi või Sinu enda poolt.
        if booked_by and (booked_by.is_vip or wc.booked_by_user_id == current_user.id):
            flash(f'{wc.name} on hetkel broneeritud. Palun oota.', 'warning')
            return redirect(url_for('index'))
            
        # Juhus B: Kinni, broneeritud Külalise poolt (ja sina oled VIP)
        elif booked_by and booked_by.is_guest and is_vip_booking:
            
            wc.status = 'booked'
            wc.booked_until = datetime.now() + duration
            wc.booked_by_user_id = current_user.id
            db.session.commit()
            
            flash(f'{wc.name} broneeritud! Aeg {int(duration.total_seconds() / 60)} minutit. Head käimist!', 'success')
            return redirect(url_for('index'))
            
        # Juhus C: Kinni, broneeritud Külalise poolt (ja sina oled Külaline/Tavakasutaja)
        elif booked_by and booked_by.is_guest and not is_vip_booking:
            flash(f'{wc.name} on hetkel broneeritud. Palun oota.', 'warning')
            return redirect(url_for('index'))


    # Kui on VABA või VIP override läks läbi, broneeri.
    wc.status = 'booked'
    wc.booked_until = datetime.now() + duration
    wc.booked_by_user_id = current_user.id
    db.session.commit()
    
    flash(f'{wc.name} broneeritud! Aeg {int(duration.total_seconds() / 60)} minutit. Head käimist!', 'success')
    return redirect(url_for('index'))


# UUS: Suunab nüüd tagasiside lehele
@app.route('/leave_wc/<int:wc_id>')
@login_required
def leave_wc(wc_id):
    """WCst lahkumine, suunab tagasiside lehele."""
    wc = db.session.get(WC, wc_id)
    
    # Kontrolli, kas kasutaja on broneerija või VIP
    if wc and wc.status == 'booked' and (wc.booked_by_user_id == current_user.id or current_user.is_vip):
        # Edastame WC ID tagasiside funktsioonile
        return redirect(url_for('feedback', wc_id=wc.id))

    flash('Sa ei saa selle WC juurest lahkuda või see pole broneeritud.', 'error')
    return redirect(url_for('index'))

# UUS MARSRUUT: Tagasiside leht
@app.route('/feedback/<int:wc_id>')
@login_required
def feedback(wc_id):
    """Tagasiside lehe kuvamine."""
    wc = db.session.get(WC, wc_id)
    if not wc:
        flash('Vetsu ei leitud.', 'error')
        return redirect(url_for('index'))
        
    # See kontroll takistab juhuslikku tagasiside lehele minemist.
    if wc.booked_by_user_id != current_user.id and not current_user.is_vip:
        flash('Sul pole õigust selle WC broneeringut käsitleda.', 'error')
        return redirect(url_for('index'))

    return render_template('feedback.html', wc=wc)

# UUS MARSRUUT: Vabastab WC ja suunab index lehele
@app.route('/release_wc_final/<int:wc_id>/<int:rating>')
@login_required
def release_wc_final(wc_id, rating):
    """Vabastab WC pärast tagasiside andmist."""
    wc = db.session.get(WC, wc_id)

    if wc and wc.status == 'booked' and (wc.booked_by_user_id == current_user.id or current_user.is_vip):
        
        # Logi tagasiside (ainult näide)
        feedback_map = {1: 'Väga halb 😭', 2: 'Halb 🙁', 3: 'Hea 🙂', 4: 'Väga hea! 😎'}
        print(f"Kasutaja {current_user.username} andis WC {wc.name} hindeks: {feedback_map.get(rating, 'Tundmatu')}") 

        # Vabasta WC
        wc.status = 'available'
        wc.booked_until = None
        wc.booked_by_user_id = None
        db.session.commit()
        
        flash(f'Täname tagasiside eest! {wc.name} on vabastatud.', 'info')
    
    else:
        flash(f'Vetsu ei saanud vabastada.', 'error')
    
    return redirect(url_for('index'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Sisselogimise marsruut. Tegeleb ka külalisena sisselogimisega."""

    if current_user.is_authenticated:
        return redirect(url_for('index'))

    # Külalisena sisselogimise loogika (GET päring)
    if request.method == 'GET' and request.args.get('guest'):
        available_guest_id = find_available_guest_id()
        
        if available_guest_id is not None:
            guest_user = db.session.get(User, available_guest_id)
            login_user(guest_user)
            flash(f'Oled edukalt sisse loginud kui {guest_user.username}.', 'info') 
            return redirect(url_for('index'))
        else:
            flash('Kõik tualetid on hõivatud (broneeritud). Palun oota!', 'warning') 
            return redirect(url_for('login'))
    
    # Parooliga sisselogimise loogika (POST päring)
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            flash(f'Oled edukalt sisse logitud kui {user.username}.', 'success')
            return redirect(url_for('index'))
        else:
            flash('Vale kasutajanimi või parool.', 'error')

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Väljalogimise marsruut."""
    logout_user()
    flash('Oled edukalt välja logitud.', 'info')
    return redirect(url_for('login'))


# --- Andmebaasi ja esialgsete andmete loomine ---

def create_initial_data(app):
    """Funktsioon andmebaasi ja vaikimisi andmete loomiseks."""
    with app.app_context():
        db.drop_all() 
        db.create_all()
        
        # 1. Loo 4 WC-d
        if not WC.query.first():
            for i in range(1, 5):
                db.session.add(WC(name=f'WC {i}'))
            db.session.commit()
            print("Loodud 4 WC-d.")
        
        # 2. Loo VIP-kasutajad (Marin, Lisette, Kata)
        vip_users = [('marin', 'parool1'), ('lisette', 'parool2'), ('kata', 'parool3')]
        for username, password in vip_users:
            if not User.query.filter_by(username=username).first():
                vip_user = User(username=username, is_vip=True, is_guest=False)
                vip_user.set_password(password) 
                db.session.add(vip_user)
                print(f"Loodud VIP-kasutaja '{username}' parooliga '{password}'.")
        
        # 3. Loo Neli Külalise kontot (paroolita)
        for i in range(1, 5):
            guest_username = f'Külaline {i}'
            if not User.query.filter_by(username=guest_username).first():
                guest_user = User(username=guest_username, is_vip=False, is_guest=True, password_hash=None)
                db.session.add(guest_user)
                print(f"Loodud külalise konto: {guest_username}.")
            
        db.session.commit()
        print("Andmebaas initsialiseeritud ja valmis.")

# --- Käivitamine ---
if __name__ == '__main__':
    create_initial_data(app) 
    app.run(debug=False, threaded=False)