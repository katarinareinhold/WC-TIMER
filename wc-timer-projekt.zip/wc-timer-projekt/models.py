from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    """Kasutaja mudel VIP staatuse ja sisselogimise jaoks."""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=True) 
    is_vip = db.Column(db.Boolean, default=False) 
    is_guest = db.Column(db.Boolean, default=False) 

    def set_password(self, password):
        """Salvestab parooli räsi."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Kontrollib parooli räsi vastu."""
        return check_password_hash(self.password_hash, password)

    def is_active(self):
        return True
    
    def get_id(self):
        return str(self.id)
    
class WC(db.Model):
    """Vetsu mudel oleku ja broneeringu haldamiseks."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    status = db.Column(db.String(10), default='available') 
    booked_until = db.Column(db.DateTime, nullable=True)
    booked_by_user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

    def __repr__(self):
        return f'<WC {self.name}: {self.status}>'